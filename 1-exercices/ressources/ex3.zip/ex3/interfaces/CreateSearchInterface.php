<?php

interface CreateFindInterface {
  function create(): void;
  function find(): void;
}