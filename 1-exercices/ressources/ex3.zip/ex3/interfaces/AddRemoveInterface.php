<?php

interface AddRemoveInterface {
  function add(): void;
  function remove(): void;
}