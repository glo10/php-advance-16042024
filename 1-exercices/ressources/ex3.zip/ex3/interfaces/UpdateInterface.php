<?php

interface UpdateInterface {
  function update(): void;
}